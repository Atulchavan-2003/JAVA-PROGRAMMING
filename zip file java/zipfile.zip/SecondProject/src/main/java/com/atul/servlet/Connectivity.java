package com.atul.servlet;

public interface Connectivity {
	boolean checkCard(String userName, String cardNo, String pin);
}
