package com.atul.servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AuthenticateUser implements Connectivity {

	public boolean checkCard(String userName, String cardNo, String pin) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Atul@123");
			
			String query = "select * from card where user_name= ? and card_no =? and pin_no = ?";
			
			PreparedStatement pstmt = con.prepareStatement(query);
			
			pstmt.setString(1,userName);
			pstmt.setString(2,cardNo);
			pstmt.setString(3, pin);
			
			ResultSet rs = pstmt.executeQuery();
			
			return rs.next();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	



}
