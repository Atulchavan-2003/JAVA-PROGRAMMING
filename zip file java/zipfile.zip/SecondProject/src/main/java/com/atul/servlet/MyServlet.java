package com.atul.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/authenticate")

public class MyServlet extends HttpServlet{

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
			System.out.println("inside the server");
			
			String userName = req.getParameter("userName");
			String cardNo = req.getParameter("cardNO");
			String pin = req.getParameter("pin");
			
			VerifyCard ref = new VerifyCard();
			
			boolean result = ref.isValidCard(userName,cardNo,pin);
			
	
			
			PrintWriter out = res.getWriter() ;
			
			if(result == true ) {
				res.sendRedirect("Valide.html");
			}
			else
			{
				res.sendRedirect("Invalide.html");
			}
			
			
			
	}

}
