<%@ page import="com.atul.ProductList.Product" %>
<%@ page import="java.util.ArrayList" %>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Checkout</title>

<style>
    body {
        margin: 0;
        font-family: "Segoe UI", sans-serif;
        background: #f1f5f9;
    }

    h2, h3 {
        text-align: center;
        color: #1f2937;
    }

    .container {
        max-width: 1100px;
        margin: 40px auto;
        padding: 20px;
    }

    /* Card grid */
    .grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-top: 30px;
    }

    .card {
        background: #ffffff;
        border-radius: 14px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.12);
        overflow: hidden;
        transition: transform 0.3s ease;
    }

    .card:hover {
        transform: translateY(-6px);
    }

    .card img {
        width: 100%;
        height: 220px;
        object-fit: contain;
        background: #f9fafb;
    }

    .content {
        padding: 18px;
        text-align: center;
    }

    .content h4 {
        margin: 10px 0;
        font-size: 18px;
        color: #111827;
    }

    .price {
        font-size: 20px;
        font-weight: bold;
        color: #16a34a;
        margin: 10px 0;
    }

    .btn {
        margin-top: 20px;
        display: flex;
        justify-content: center;
    }

    button {
        padding: 14px 30px;
        background: #16a34a;
        color: #fff;
        border: none;
        border-radius: 10px;
        font-size: 16px;
        cursor: pointer;
        transition: background 0.3s;
    }

    button:hover {
        background: #15803d;
    }

    .total {
        text-align: center;
        font-size: 22px;
        margin-top: 30px;
        font-weight: bold;
        color: #111827;
    }

</style>
</head>

<body>

<div class="container">

<%
    Product product = (Product) request.getAttribute("product");
    ArrayList<Product> cart = (ArrayList<Product>) request.getAttribute("cart");
    Integer totalPrice = (Integer) request.getAttribute("totalPrice");
%>

<!-- ================= BUY NOW ================= -->
<% if (product != null) { %>

<h2>Buy Now</h2>

<div class="grid" style="justify-content:center;">
    <div class="card">
        <img src="<%= product.getProductImage() %>" alt="Product">
        <div class="content">
            <h4><%= product.getProductName() %></h4>
            <div class="price">Rs <%= product.getProductPrice() %></div>

            <form action="payment.jsp" method="post">
                <input type="hidden" name="productId" value="<%= product.getProductId() %>">
                <input type="hidden" name="price" value="<%= product.getProductPrice() %>">
                <button>Confirm Order</button>
            </form>
        </div>
    </div>
</div>

<% } %>

<!-- ================= BUY ALL ================= -->
<% if (cart != null && !cart.isEmpty()) { %>

<h2>Buy All</h2>

<div class="grid">
<% for (Product p : cart) { %>
    <div class="card">
        <img src="<%= p.getProductImage() %>" alt="Product">
        <div class="content">
            <h4><%= p.getProductName() %></h4>
            <div class="price">Rs <%= p.getProductPrice() %></div>
        </div>
    </div>
<% } %>
</div>

<div class="total">
    Total Amount :Rs <%= totalPrice %>
</div>

<div class="btn">
    <form action="ConfirmOrderServlet" method="post">
        <input type="hidden" name="type" value="cart">
        <button>Confirm All Orders</button>
    </form>
</div>

<% } %>

</div>
</body>
</html>
