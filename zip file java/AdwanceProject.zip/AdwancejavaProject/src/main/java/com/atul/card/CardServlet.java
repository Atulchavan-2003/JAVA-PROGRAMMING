package com.atul.card;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import com.atul.ProductList.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/CardServlet")
public class CardServlet extends HttpServlet {

protected void doPost(HttpServletRequest req, HttpServletResponse res)
throws IOException, ServletException {

    String cardNo = req.getParameter("cardNumber");
    String cvv = req.getParameter("cvv");

    int productId = Integer.parseInt(req.getParameter("productId"));
    double price = Double.parseDouble(req.getParameter("productPrice"));
    String paymentMode = req.getParameter("paymentMode");
    	
    HttpSession session = req.getSession();
  
    boolean valid = CardDAO.isValidCard(cardNo, cvv);

    if (valid) {
      
        
        
        List<Product> products = ( List<Product>)session.getAttribute("cart");
        

        Iterator<Product> it = products.iterator();
        while (it.hasNext()) {
            Product product = it.next();
            if (product.getProductId() == productId) {
                it.remove();   // ✅ safe removal
                break;
            }
        }
        req.getRequestDispatcher("placeOrder").forward(req, res);
      
    } else {
        req.setAttribute("error", " Invalid Card Details");
        req.getRequestDispatcher("card.jsp").forward(req, res);
    }
}
}
