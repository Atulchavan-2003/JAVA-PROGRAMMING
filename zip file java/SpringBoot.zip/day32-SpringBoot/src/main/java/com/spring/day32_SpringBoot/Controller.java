package com.spring.day32_SpringBoot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller  {
	
	@Autowired 
	UserRepo repo;
	
	
	@GetMapping("/hello")
	public String showGreeting(){
		return "hello Boot";
	}
	

    @GetMapping("/hello2")
    public Student Greeting() {

        Student s = new Student();
        s.setId(101);
        s.setName("Atul Chavan");
        s.setAge(22);

        return s; 
    }
    

    
    @PostMapping("/student")
    public String storeRecord(@RequestParam int studentId, @RequestParam String studentName, @RequestParam int studentAge) {

        Student s = new Student();
        
        s.setId(studentId);
        s.setName(studentName);
        s.setAge(studentAge);

        repo.save(s);
        return "Record Added";
    }

	    
}
