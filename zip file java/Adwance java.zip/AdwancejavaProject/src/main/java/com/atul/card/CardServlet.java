package com.atul.card;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CardServlet")
public class CardServlet extends HttpServlet {

protected void doPost(HttpServletRequest req, HttpServletResponse res)
throws IOException, ServletException {

    String cardNo = req.getParameter("cardNumber");
    String cvv = req.getParameter("cvv");

    int productId = Integer.parseInt(req.getParameter("productId"));
    double price = Double.parseDouble(req.getParameter("productPrice"));
    String paymentMode = req.getParameter("paymentMode");

  
    boolean valid = CardDAO.isValidCard(cardNo, cvv);

    if (valid) {
      
        req.getRequestDispatcher("placeOrder").forward(req, res);
    } else {
        req.setAttribute("error", " Invalid Card Details");
        req.getRequestDispatcher("card.jsp").forward(req, res);
    }
}
}
