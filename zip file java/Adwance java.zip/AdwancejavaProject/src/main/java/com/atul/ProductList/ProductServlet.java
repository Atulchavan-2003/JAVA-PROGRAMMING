package com.atul.ProductList;

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.*;
import jakarta.servlet.http.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Pservlet")
public class ProductServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
			    
				System.out.println("inside product servlet");
				String action = req.getParameter("action");
				
				HttpSession session = req.getSession();
				
				ArrayList<Product> cart = (ArrayList<Product>) session.getAttribute("cart");
				
				if(cart == null ) {
					cart = new ArrayList<Product>();
				}
				
								
				if("add".equals(action)) {
					   
					   String totalPrice =  (String) session.getAttribute("totalPrice");
					   
//					   if(totalPrice == null) {
//						   res.sendRedirect("/Product.jsp");
//					   }
					   
					   
					   
					   
					if(session.getAttribute("userName")!=null) {
							
						System.out.println("inside add cart");
						int productId =Integer.parseInt(req.getParameter("productId"));
						String productName = req.getParameter("productName");
						String image = req.getParameter("productImage");
						String price = req.getParameter("productPrice");
						
						totalPrice += Integer.parseInt(price);
						
						session.setAttribute("totalPrice",totalPrice);
						
						System.out.println(productName);
						Product product = new Product(productName, image, price);
						product.setProductId(productId);
						System.out.println("add sucsesfull");
						cart.add(product);
					
						session.setAttribute("cart", cart);
						
						res.sendRedirect(req.getContextPath() + "/products");
						
					}else {
						
						 session.setAttribute("msg", "Please login first Guest users cannot add items to cart");
						 
						 res.sendRedirect("login.jsp");
					}
					
				}
				else if ("remove".equals(action)) {

				    int index = Integer.parseInt(req.getParameter("index"));
				    System.out.println("inside remove: " + cart.get(index).getProductId());
				    
				    cart.remove(index);
				    
				    
				    
				    session.setAttribute("cart", cart);
				    res.sendRedirect("Cart.jsp");
				    
				    
				}else if ("buy".equals(action)) {
					
				     int index = Integer.parseInt(req.getParameter("index"));
				     
				     Product product = (Product) cart.get(index);
				     req.setAttribute("product", product);
				     
				     
					RequestDispatcher rd = req.getRequestDispatcher("/buy");
					rd.forward(req, res);
				}
				
				
				
		
	}

}
