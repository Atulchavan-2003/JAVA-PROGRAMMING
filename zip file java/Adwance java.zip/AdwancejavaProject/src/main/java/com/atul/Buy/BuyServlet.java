package com.atul.Buy;

import java.io.IOException;

import com.atul.ProductList.Product;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/buy")
public class BuyServlet extends HttpServlet {

    protected void service(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        Product product = (Product) req.getAttribute("product");

      
        if(product == null){
            res.sendRedirect("Cart.jsp");
            return;
        }
        
        	System.out.println("inside buy servlet");
        req.setAttribute("product", product);
        RequestDispatcher rd = req.getRequestDispatcher("/BuyNow.jsp");
        rd.forward(req, res);
    }
}
