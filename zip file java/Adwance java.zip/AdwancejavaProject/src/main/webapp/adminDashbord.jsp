<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>

<style>
   
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #f5f7fa;
        color: #1f2937;
    }

    .header {
        background: linear-gradient(90deg, #2563eb, #3b82f6);
        color: white;
        padding: 20px;
        text-align: center;
        font-size: 28px;
        font-weight: bold;
        letter-spacing: 1px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    .navbar {
        display: flex;
        justify-content: center;
        gap: 20px;
        background: #1e293b;
        padding: 12px 0;
    }

    .navbar a {
        color: #f1f5f9;
        text-decoration: none;
        font-weight: 600;
        padding: 8px 15px;
        border-radius: 5px;
        transition: background 0.3s, color 0.3s;
    }

    .navbar a:hover {
        background: #2563eb;
        color: white;
    }

    .container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        padding: 40px 20px;
        gap: 25px;
    }

    .card {
        background: white;
        width: 240px;
        padding: 25px 20px;
        border-radius: 12px;
        box-shadow: 0 6px 15px rgba(0,0,0,0.1);
        text-align: center;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.15);
    }

    .card h3 {
        font-size: 20px;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }

    .card a {
        display: block;
        background: #2563eb;
        color: white;
        padding: 10px;
        border-radius: 8px;
        text-decoration: none;
        margin-top: 10px;
        font-weight: 600;
        transition: background 0.3s;
    }

    .card a:hover {
        background: #1d4ed8;
    }

    .footer {
        background: #1e293b;
        color: #cbd5e1;
        text-align: center;
        padding: 15px;
        margin-top: 40px;
        font-size: 14px;
    }

  
    @media (max-width: 768px) {
        .container {
            flex-direction: column;
            align-items: center;
        }
    }
</style>
</head>

<body>

<div class="header">
    ADMIN DASHBOARD
</div>

<div class="navbar">
    <a href="Product.jsp">Home</a>
    <a href="addProduct.jsp">Add Product</a>
    <a href="updateProduct.jsp">Update Product</a>
    <a href="DeleteProduct.jsp">Delete Product</a>
    <a href="<%=request.getContextPath()%>/logout">Logout</a>
</div>

<div class="container">

    <div class="card">
        <h3>📦 Products</h3>
        <a href="addProduct.jsp">➕ Add Product</a>
   
    </div>
     
     
     <div class="card">
        <h3>Update product</h3>
        <a href="updateProduct.jsp">✏️ Update Product</a>
     </div>
     
     <div class="card">
      <h3>Delete Product</h3>
      	<a href="DeleteProduct.jsp">❌ Delete Product</a>
     </div>
     
    <div class="card">
        <h3>👤 Users</h3>
        <a href="<%=request.getContextPath()%>/viewUsers">View Users</a>
    </div>

    <div class="card">
        <h3>📑 Orders</h3>
        <a href="<%=request.getContextPath()%>/viewOrders">View Orders</a>
    </div>
<%-- 
    <div class="card">
        <h3>💳 Payments</h3>
        <a href="<%=request.getContextPath()%>/viewPayments">Payment Details</a>
    </div> --%>

</div>

<div class="footer">
    © 2025 MyShop | Admin Panel
</div>

</body>
</html>
