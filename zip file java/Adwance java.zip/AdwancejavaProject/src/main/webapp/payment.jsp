<html>
<head>
<title>Select Payment</title>
<style>
body{font-family:Arial;background:#f1f5f9}
.box{
    width:420px;
    margin:50px auto;
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 10px 25px rgba(0,0,0,.2);
}
h2{text-align:center}
.option{margin:15px 0}
button{
    width:100%;
    padding:10px;
    background:#2563eb;
    color:white;
    border:none;
    border-radius:6px;
    font-size:16px;
}
</style>
</head>

<body>

<div class="box">
    <h2>💳 Select Payment Method</h2>

    <form action="card.jsp" method="post">
         <% if( session.getAttribute("userName") != null){ %>
        <h2>Product Price: $<%= request.getParameter("price")%></h2>
        <h2> product Id:<%= request.getParameter("productId") %></h2>
        <%
         }else{
        	
        %>
           <h1>user not login</h1>
           <%
           }
           %>
        <input type="hidden" name="productId" value="<%= request.getParameter("productId") %>">
        <input type="hidden" name="productName" value="<%= request.getParameter("productName") %>">
        <input type="hidden" name="productPrice" value="<%= request.getParameter("price") %>">
       
       
        <div class="option">
            <input type="radio" name="paymentMode" value="CARD"> Debit / Credit Card
        </div>


        <button>Pay Now</button>
    </form>
</div>

</body>
</html>
