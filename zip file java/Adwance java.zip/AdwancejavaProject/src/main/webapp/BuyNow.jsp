<%@ page import="com.atul.ProductList.Product" %>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Buy Now</title>
<style>
    /* General styles */
    body {
        font-family: 'Arial', sans-serif;
        background: #f1f5f9;
        margin: 0;
        padding: 0;
    }

    /* Center container */
    .container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        padding: 20px;
    }

    /* Card */
    .card {
        width: 400px;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        overflow: hidden;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.25);
    }

    /* Product image */
    .card img {
        width: 100%;
        height: 250px;
        object-fit: contain;
        background: #f9f9f9;
    }

    /* Content */
    .card .content {
        padding: 20px;
    }

    .card h2 {
        font-size: 24px;
        margin: 0 0 10px;
        color: #333;
    }

    .card .price {
        font-size: 22px;
        color: #16a34a;
        font-weight: bold;
        margin-bottom: 20px;
    }

    /* Button */
    .card button {
        width: 100%;
        padding: 12px;
        background: #16a34a;
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        cursor: pointer;
        transition: background 0.3s;
    }

    .card button:hover {
        background: #138d3a;
    }

    /* Fallback text */
    .no-product {
        text-align: center;
        font-size: 18px;
        color: #777;
    }
</style>
</head>
<body>
<div class="container">
<%
    Product product = (Product) request.getAttribute("product");
    if(product != null) {
%>
    <div class="card">
        <img src="<%= product.getProductImage() %>"alt="Product Image">
        <div class="content">
            <h2><%= product.getProductName() %></h2>
            <div class="price">₹<%= product.getProductPrice() %></div>
            <form action="payment.jsp" method="post">
                <input type="hidden" name="productId" value="<%= product.getProductId() %>">
                <input type="hidden" name="productName" value="<%= product.getProductName() %>">
                <input type="hidden" name="price" value="<%= product.getProductPrice() %>">
                <button>Confirm Order</button>
            </form>
        </div>
    </div>
<%
    } else {
%>
    <div class="no-product">
        <p>Product details not available.</p>
    </div>
<%
    }
%>
</div>
</body>
</html>
