<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="java.util.ArrayList" %>
<%@ page import="com.atul.ProductList.Product" %>

<%
    ArrayList<Product> cart = (ArrayList<Product>) session.getAttribute("cart");

    String userName = (String) session.getAttribute("userName");
    if(userName == null){
        userName = "Guest";
    }
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Cart</title>

<style>
    body{
        font-family: Arial, sans-serif;
        background:#f4f6f9;
        padding:20px;
    }

    h2{
        text-align:center;
        margin-bottom:20px;
    }

    table{
        width:100%;
        border-collapse:collapse;
        background:white;
        box-shadow:0 4px 8px rgba(0,0,0,0.1);
    }

    th{
        background:#2c3e50;
        color:white;
        padding:12px;
    }

    td{
        padding:10px;
        text-align:center;
        border-bottom:1px solid #ddd;
    }

    tr:hover{
        background:#f1f1f1;
    }

    img{
        border-radius:6px;
    }

    /* buttons */
    .btn{
        padding:8px 14px;
        border-radius:6px;
        border:none;
        font-weight:bold;
        cursor:pointer;
        transition:0.3s;
    }

    .btn-remove{
        background:#e74c3c;
        color:white;
    }

    .btn-remove:hover{
        background:#c0392b;
        transform:scale(1.05);
    }

    .btn-buy{
        background:#27ae60;
        color:white;
    }

    .btn-buy:hover{
        background:#1e8449;
        transform:scale(1.05);
    }

    .empty{
        padding:20px;
        font-size:18px;
        color:#777;
    }

    .home-link{
        display:inline-block;
        margin-top:20px;
        text-decoration:none;
        font-weight:bold;
        color:#2980b9;
    }

    .home-link:hover{
        text-decoration:underline;
    }
</style>

</head>
<body>

<h2>🛒 My Cart</h2>

<table>
<tr>
    <th>User</th>
    <th>Product ID</th>
    <th>Name</th>
    <th>Image</th>
    <th>Price</th>
    <th>Remove</th>
    <th>Buy</th>
</tr>

<%
if(cart != null && !cart.isEmpty()){
    for(int i=0; i<cart.size(); i++){
        Product p = cart.get(i);
%>

<tr>
    <td><%= userName %></td>
    <td><%= p.getProductId() %></td>
    <td><%= p.getProductName() %></td>
    <td>
        <img src="<%= p.getProductImage() %>" width="80" height="80">
    </td>
    <td>₹ <%= p.getProductPrice() %></td>

    <td>
        <form action="Pservlet" method="post">
            <input type="hidden" name="action" value="remove">
            <input type="hidden" name="index" value="<%= i %>">
            <button class="btn btn-remove">Remove</button>
        </form>
    </td>

    <td>
        <form action="Pservlet" method="post">
            <input type="hidden" name="action" value="buy">
            <input type="hidden" name="index" value="<%= i %>">
            <button class="btn btn-buy">Buy</button>
        </form>
    </td>
</tr>


<%
    }
}else{
%>

<tr>
    <td colspan="7" class="empty">Your cart is empty 🛒</td>
</tr>

<% } %>


    <%
       String totalPrice = (String) session.getAttribute("totalPrice");
    
       if(totalPrice!=null){
    %>
    
        <div><%= totalPrice %></div>
 <%
 }
 %>

</table>

<a href="Product.jsp" class="home-link">← Continue Shopping</a>

</body>
</html>
