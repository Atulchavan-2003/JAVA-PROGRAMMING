package com.atul.graph;

public class Node {
	String data;

	public Node(String data) {
		super();
		this.data = data;
	}
	
}
